/**
 * 脚本错误信息上报 
 */
module.exports = {
  loginError: {
    event: "login_error",
    wx_error: "wx_login_error",
    server_error: "server_login_error"
  },
  vipError:{
    event:"vip_info",
    vip_error:"vip_error"
  }
}